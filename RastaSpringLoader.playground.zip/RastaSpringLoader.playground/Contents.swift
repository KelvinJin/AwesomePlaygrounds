//: Playground - noun: a place where people can play

import UIKit
import CoreGraphics


extension CGFloat {
    func splitEqually(piece: Int) -> [(CGFloat, CGFloat)] {
        var cursor: CGFloat = 0.0
        let step = self / CGFloat(piece)
        
        return (0..<piece).map { _ in
            let r = (cursor, cursor + step)
            cursor += step
            return r
        }
    }
    
    func toEaseIn() -> CGFloat {
        var processed_ratio: CGFloat = self
        if self < 0.5 {
            processed_ratio =  (1 - pow(1 - self, 3.0)) * 8 / 14
        } else {
            processed_ratio = 1 - (1 - pow(self, 3.0)) * 8 / 14
        }
        
        return processed_ratio
    }
    
    func toEaseInOut(power: CGFloat = 2) -> CGFloat {
        return pow(self, power) / (pow(self, power) + pow(1 - self, power))
    }
}

extension UIColor {
    convenience init(hex: String) {
        let characterSet = NSCharacterSet.whitespaceAndNewlineCharacterSet().mutableCopy() as! NSMutableCharacterSet
        characterSet.formUnionWithCharacterSet(NSCharacterSet(charactersInString: "#"))
        let cString = hex.stringByTrimmingCharactersInSet(characterSet).uppercaseString
        if (cString.utf16.count != 6) {
            self.init(white: 1.0, alpha: 1.0)
        } else {
            var rgbValue: UInt32 = 0
            NSScanner(string: cString).scanHexInt(&rgbValue)
            
            self.init(red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
                      green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
                      blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
                      alpha: CGFloat(1.0))
        }
    }
    
    func toHexString() -> String {
        var r:CGFloat = 0
        var g:CGFloat = 0
        var b:CGFloat = 0
        var a:CGFloat = 0
        
        getRed(&r, green: &g, blue: &b, alpha: &a)
        
        let rgb: Int = (Int)(r * 255) << 16 | (Int)(g * 255) << 8 | (Int)(b * 255) << 0
        
        return NSString(format:"%06x", rgb) as String
    }
}

class RainbowCircle: UIView {
    let radius: CGFloat = 30
    let lineWidth: CGFloat = 10
    let duration: Double = 0.57
    let timeFunction = CAMediaTimingFunction(controlPoints: 0.86, 0.67, 0.82, 0.57)
    let curveColors: [UIColor] = ["D2061A", "EFD600", "02A126"].map { UIColor(hex: $0) }
    let startAngle: CGFloat = CGFloat(-M_PI)
    let lengthAngle: CGFloat = CGFloat(M_PI)
    var originalPoints: [(CGFloat, CGFloat)] = []
    
    var curveLayers: [CAShapeLayer] = []
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setup()
    }
    
    func setup() {
        originalPoints = lengthAngle.splitEqually(curveColors.count).map({ ($0.0 + startAngle, startAngle + lengthAngle) })
        
        originalPoints.enumerate().forEach { i, value in
            let curveLayer = fatCurve(value.0, end: value.1, color: curveColors[i].CGColor)
            layer.addSublayer(curveLayer)
            curveLayers.append(curveLayer)
        }
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(didTapOnView(_:)))
        addGestureRecognizer(tapGesture)
    }
    
    class LayerAnimation {
        var next: LayerAnimation?
        var animationBlock: () -> Void
        
        init(block: () -> Void) {
            animationBlock = block
        }
        
        func then(block: () -> Void) -> LayerAnimation {
            let next = LayerAnimation(block: block)
            self.next = next
            return next
        }
        
        func commit() {
            CATransaction.begin()
            CATransaction.setCompletionBlock {
                self.next?.commit()
            }
            animationBlock()
            CATransaction.commit()
        }
    }
    
    func didTapOnView(gesture: UITapGestureRecognizer) {
        // Start the animation.
        
        let center = CGPoint(x: bounds.width / 2, y: bounds.height / 2)
        let radius = self.radius
        
        let starter = LayerAnimation {
            self.addStrokeStartAnimation(0, toValue: 0.9)
            self.addPositionAnimation(center.x, toValue: center.x - radius)
        }
        
        starter.then {
            self.flip(false)
            
            self.addStrokeStartAnimation(0.9, toValue: 0, easeOut: false)
            self.addPositionAnimation(center.x + radius, toValue: center.x, easeOut: false)
            }.then {
                self.addStrokeStartAnimation(0, toValue: 0.9)
                self.addPositionAnimation(center.x, toValue: center.x - radius)
                self.addRotateAnimation(-0.001, toValue: CGFloat(-M_PI), clock: false)
            }.then {
                self.flip()
                
                self.addStrokeStartAnimation(0.9, toValue: 0, easeOut: false)
                self.addPositionAnimation(center.x + radius, toValue: center.x, easeOut: false)
                self.addRotateAnimation(CGFloat(-M_PI), toValue: CGFloat(0), easeOut: false)
            }.then {
                starter.commit()
        }
        
        starter.commit()
    }
    
    private func flip(left: Bool = true) {
        let center = CGPoint(x: bounds.width / 2, y: bounds.height / 2)
        
        curveLayers.enumerate().forEach { i, value in
            let point = originalPoints[i]
            value.path = left ? UIBezierPath(arcCenter: center, radius: radius, startAngle: point.0, endAngle: point.1, clockwise: true).CGPath : UIBezierPath(arcCenter: center, radius: radius, startAngle: CGFloat(M_PI) - point.0, endAngle: CGFloat(M_PI) - point.1, clockwise: false).CGPath
        }
    }
    
    private func addRotateAnimation(fromValue: CGFloat, toValue: CGFloat, clock: Bool = true, easeOut: Bool = true) {
        let rotateAnimation = CABasicAnimation(keyPath: "transform")
        let fromTransform = CATransform3DMakeRotation(fromValue, 0, 0, clock ? 1 : -1)
        let toTransform = CATransform3DMakeRotation(toValue, 0, 0, clock ? 1 : -1)
        rotateAnimation.timingFunction = easeOut ?
            CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseOut) :
            CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseIn)
        rotateAnimation.fromValue = NSValue(CATransform3D: fromTransform)
        rotateAnimation.toValue = NSValue(CATransform3D: toTransform)
        rotateAnimation.duration = duration
        rotateAnimation.fillMode = kCAFillModeForwards
        rotateAnimation.removedOnCompletion = false
        
        curveLayers.forEach {
            $0.addAnimation(rotateAnimation, forKey: "rotate animation")
        }
    }
    
    private func addStrokeStartAnimation(fromValue: CGFloat, toValue: CGFloat, easeOut: Bool = true) {
        let strokeStartAnimation = CABasicAnimation(keyPath: "strokeStart")
        strokeStartAnimation.timingFunction = easeOut ?
            CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseOut) :
            CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseIn)
        strokeStartAnimation.fromValue = fromValue
        strokeStartAnimation.toValue = toValue
        strokeStartAnimation.duration = duration
        strokeStartAnimation.fillMode = kCAFillModeForwards
        strokeStartAnimation.removedOnCompletion = false
        
        curveLayers.forEach {
            $0.addAnimation(strokeStartAnimation, forKey: "stroke start animation")
        }
    }
    
    private func addPositionAnimation(fromValue: CGFloat, toValue: CGFloat, easeOut: Bool = true) {
        let moveAnimation = CABasicAnimation(keyPath: "position.x")
        moveAnimation.timingFunction = easeOut ?
            CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseOut) :
            CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseIn)
        moveAnimation.fromValue = fromValue
        moveAnimation.toValue = toValue
        moveAnimation.duration = duration
        moveAnimation.fillMode = kCAFillModeForwards
        moveAnimation.removedOnCompletion = false
        
        curveLayers.forEach {
            $0.addAnimation(moveAnimation, forKey: "move animation")
        }
    }
    
    private func fatCurve(start: CGFloat, end: CGFloat, color: CGColor) -> CAShapeLayer {
        let curveLayer = CAShapeLayer()
        
        let center = CGPoint(x: bounds.width / 2, y: bounds.height / 2)
        curveLayer.frame = bounds
        
        curveLayer.fillColor = UIColor.clearColor().CGColor
        curveLayer.strokeColor = color
        curveLayer.lineCap = kCALineCapRound
        curveLayer.lineWidth = lineWidth
        let curvePath = UIBezierPath(arcCenter: center, radius: radius, startAngle: start, endAngle: end, clockwise: true)
        curveLayer.path = curvePath.CGPath
        
        return curveLayer
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        setup()
    }
}

import XCPlayground
XCPlaygroundPage.currentPage.liveView = RainbowCircle(frame: CGRect(x: 0, y: 0, width: 200, height: 200))
